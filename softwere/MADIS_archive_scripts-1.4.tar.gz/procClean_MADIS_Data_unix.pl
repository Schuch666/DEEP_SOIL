#!/usr/bin/perl -w
#
#
# This script ftps, dumps, and cleanups the data files per the ftp.par1.txt
# parameter file in one day increments.  The purpose of this script is to 
# enable the user to process a large quatity of MADIS data with limited disk
# space.
#
# The download data files are removed, leaving only the MADIS API output
# files.
#
# The ftp.par1.txt and api.par1.txt file setting are overwritten during the
# processing to run one day at a time.  The orignal settings are restored if
# the program terminates normally.
#
# This only works for unix/Linux.
#
# See README.unix for more information
#
# Notes:
#
# 1. Required enviromental variables
#    - MADIS_DATA   pointed to the root directory for the MADIS data.
#    - MADIS_BIN    pointed to API binaries directory
#    - MADIS_STATIC pointed to API static directory
#
# 2. Required path settings:
#    - Perl bin directory
#
# 3. Editing the ftp.par1.txt file:
#    - The parameter file controls the time range, dataset selection, and
#      special file versions.
#      - The time range is the starting and ending date and hour.
#        - Line 4 is start date and time
#        - Line 5 is end date and time
#      - The dataset selection is the included datasets.
#        - Line 10 is first dataset line
#      - The special file versions are expanded data files for approved users.
#
# 4. Put ftp.par1.txt file and get_MADIS_Data_unix.pl in the same directory.
#    
# 5. The data is downloaded below the MADIS_DATA enviromental variable.
#    Any missing subdirectories are created.
#
# 6. "$" and "@" in input's might have to be escaped depending on perl version
#    and operating configuration.  Ex. ab$5 --> ab\$5
#
# 7. The downloaded files are un-gzip, processed, and removed by this script.   
#
# 8. A dump template file is only required if the dataset dump is requested. 
#
# 9. A temporary file named *dump.txt.tmp" is used to hold the output information
#    for internal processing.
#
# 10. All parameter files are expected to be in the run time directory, the
#    same directory as run_MADIS_API.pl.
#
#
# Special variables information:
#
#  The keys for %datasetpath and %datasetkeys must be the same.
#  The values for %datasetkeys and the keys for %apidsyn must be the same.
#  The values for @apidsorder  and the keys for %apidsyn must be the same.
#
#  %datasetpath -> datasets locations
#  @datasetpath -> list of datasets to download
#  %datasetkeys -> datasets internal names
#  @datasetkeys -> datasets unique name in parameter files
#  @apipartmhdlns -> api parameter file time and header information
#  @apiparlns -> api parameter file datasets lines without [YN] setting
#  %apidsyn ->  api parameter file datasets lines [YN] setting
#  @apidsorder ->  api parameter file datasets order
#
# Mods
# 08/05/2015 Benjamin  It isn't ftp anymore
#

$|=1;

use strict;
use POSIX qw(:termios_h);

my($cat,@datasets,$ds,@dspar,$exepath,@f,$f,$hour,$is,$key,$ln,$ls,$mday);
my($mdyhms,$min,$mon,$ofile,$ofiletmp,%ofiles,$p,@res,$rest,$sec,$tmpln);
my($year,$yrdif,@datasetkeys,%datasetkeys,@knowndskeys,$wday,$yday);
my($sprpln,@tmp,$dsdefines,@dspars,@dspartmp,$i,$dskeys);
my($unm,$pnm,$dskey,$interactive,$ies,$start,$end,$i1,$dsnm);
my(%datasetpath,@datasetpath);
my($curday,$l,$path,@dirfiles,$tmhr,$filehr,@datafiles,$df);

$interactive = 1;
$cat = "cat";
################################################################
# MADIS dataset locations under MADIS_DATA
$#datasetpath = -1;
(%datasetpath) = (
		    "METAR"=>"point/metar/netcdf",
		    "SAO"=>"point/sao/netcdf",
		    "MARITIME"=>"point/maritime/netcdf",
		    "MODERNIZED COOP"=>"LDAD/coop/netCDF",
		    "URBANET"=>"LDAD/urbanet/netCDF",
		    "INTEGRATED MESONET"=>"LDAD/mesonet/netCDF",
		    "HYDROLOGICAL SURFACE"=>"LDAD/hydro/netCDF",
		    "MULTI-AGENCY PROFILER"=>"LDAD/profiler/netCDF",
		    "SNOW"=>"LDAD/snow/netCDF",
		    "WISDOM"=>"LDAD/WISDOM/netCDF",
		    "SATELLITE WIND - 3 HOUR"=>"point/HDW/netcdf",
		    "SATELLITE WIND - 1 HOUR"=>"point/HDW1h/netcdf",
		    "SATELLITE SOUNDING"=>"point/POES/netcdf",
		    "SATELLITE RADIANCE"=>"point/satrad/netcdf",
		    "RADIOMETER"=>"point/radiometer/netcdf",
		    "RADIOSONDE"=>"point/raob/netcdf",
		    "AUTOMATED AIRCRAFT REPORTS"=>"point/acars/netcdf",
		    "AUTOMATED AIRCRAFT PROFILES AT AIRPORTS"=>
		      "point/acarsProfiles/netcdf",
		    "NOAA PROFILER NETWORK"=>"point/profiler/netcdf",
                    "CRN" =>"LDAD/crn/netCDF",
                    "HCN" =>"LDAD/hcn/netCDF",
                    "NEPP" =>"LDAD/nepp/netCDF",
                    "HFMETAR" =>"LDAD/hfmetar/netCDF",
		    );



################################################################
# MADIS dataset locations under MADIS_DATA
(%datasetkeys) = (
		    "METAR"=>"sfc",
		    "SAO"=>"sfc",
		    "MARITIME"=>"sfc",
		    "MODERNIZED COOP"=>"sfc",
		    "URBANET"=>"sfc",
                    "CRN" =>"sfc",
                    "HCN" =>"sfc",
                    "NEPP" =>"sfc",
                    "HFMETAR" =>"hfmetar",
		    "INTEGRATED MESONET"=>"sfc",
		    "HYDROLOGICAL SURFACE"=>"hydro",
		    "MULTI-AGENCY PROFILER"=>"map",
		    "SNOW"=>"snow",
		    "WISDOM"=>"WISDOM",
		    "SATELLITE WIND - 3 HOUR"=>"satwnd",
		    "SATELLITE WIND - 1 HOUR"=>"satwnd",
		    "SATELLITE SOUNDING"=>"satsnd",
		    "SATELLITE RADIANCE"=>"satrad",
		    "RADIOMETER"=>"rdmtr",
		    "RADIOSONDE"=>"raob",
		    "AUTOMATED AIRCRAFT REPORTS"=>"acars",
		    "AUTOMATED AIRCRAFT PROFILES AT AIRPORTS"=>
		      "acarsp",
		    "NOAA PROFILER NETWORK"=>"npn",
		    );

# Conversion of key code to txt, par, and exe code
my(%key2tpe) = (
	      "sfc"=>"sfc",
	      "hydro"=>"hydro",
	      "map"=>"map",
	      "snow"=>"snow",
	      "satwnd"=>"satwnd",
	      "satsnd"=>"satsnd",
	      "rdmtr"=>"rdmtr",
	      "raob"=>"raob",
	      "satrad"=>"satrad",
	      "acars"=>"acars",
	      "acarsp"=>"acarsp",
	      "npn"=>"npn",
	      "WISDOM"=>"wisdom",
);


my(@apipartmhdlns) = (
"---------------------------------------------------------------------------------",
"Date and time (YYYYMMDD HH)",
"---------------------------",
"20071220 21     Start",
"20071220 23     End",
"",
"---------------------------------------------------------------------------------",
"Process (Y/N)   Dataset                                           Output File",
"-------------   -------                                           -----------",
		);
my(@apiparlns) = (
"               Meteorological Surface                            sfcdump.txt",
"               Hydrological Surface                              hydrodump.txt",
"               Multi-Agency Profiler                             mapdump.txt",
"               Snow                                              snowdump.txt",
"               WISDOM                                            wisdomdump.txt",
"               Satellite Wind                                    satwnddump.txt",
"               Satellite Sounding                                satsnddump.txt",
"               Satellite Radiance                                satraddump.txt",
"               Radiometer                                        rdmtrdump.txt",
"               Radiosonde                                        raobdump.txt",
"               Automated Aircraft Reports                        acarsdump.txt",
"               Automated Aircraft Profiles at Airports           acarspdump.txt",
"               NOAA Profiler Network                             npndump.txt"
		);
my(%apidsyn) = (
		   "sfc"=>"N",
		   "hydro"=>"N",
		   "map"=>"N",
		   "snow"=>"N",
		   "WISDOM"=>"N",
		   "satwnd"=>"N",
		   "satsnd"=>"N",
		   "satrad"=>"N",
		   "rdmtr"=>"N",
		   "raob"=>"N",
		   "acars"=>"N",
		   "acarsp"=>"N",
		   "npn"=>"N",
		    );
my(@apidsorder) = (
		   "sfc",
		   "hydro",
		   "map",
		   "snow",
		   "WISDOM",
		   "satwnd",
		   "satsnd",
		   "satrad",
		   "rdmtr",
		   "raob",
		   "acars",
		   "acarsp",
		   "npn",
		    );




my($MADIS_DATA) = $ENV{'MADIS_DATA'};
if($MADIS_DATA eq ""){
    print "MADIS_DATA is not defined, please define it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
elsif(! -d "$MADIS_DATA"){
    print "MADIS_DATA ($MADIS_DATA) directory does not exist, please create";
    print " it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}

my($MADIS_STATIC) = $ENV{'MADIS_STATIC'};
if($MADIS_STATIC eq ""){
    print "MADIS_STATIC is not defined, please define it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
elsif(! -d "$MADIS_STATIC"){
    print "MADIS_STATIC ($MADIS_STATIC) directory does not exist, please "; 
    print "create it then run again.\n"; 
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
my($MADIS_BIN) = $ENV{'MADIS_BIN'};
if($MADIS_BIN eq ""){
    print "MADIS_BIN is not defined, please define it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
elsif(! -d "$MADIS_BIN"){
    print "MADIS_BIN ($MADIS_BIN) directory does not exist, please create ";
    print "it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}



(@datasetkeys) = sort keys %datasetkeys;
$#knowndskeys = -1;

foreach $dskeys (@datasetkeys){
    push(@knowndskeys,"\"$dskeys\"\n")
}


# username/password
print " Enter username: ";
sysread(STDIN, $unm, 50);
chomp ($unm);
print " Enter password: ";
sysread(STDIN, $pnm, 50);
chomp ($pnm);
$unm =~ s/^\s//g;
$unm =~ s/\s$//g;
$pnm =~ s/^\s//g;
$pnm =~ s/\s$//g;

#####
#Read ftp.par1.txt
# read processing parms
open(IN,"ftp.par1.txt") || die "Could not open ftp.par1.txt file in this directory, please check that the file exists and is readable.\n";
my(@orgftppars);
(@orgftppars) =  <IN>;
close(IN);
my(@tmpftppars);
@tmpftppars = @orgftppars;
my(@ftppars);
@ftppars = @orgftppars;
chomp(@ftppars);

shift(@ftppars);
shift(@ftppars);
shift(@ftppars);
# Line 4 start time in "YYYYMMDD HH" format
my($stime) = shift(@ftppars); 
# Line 5 end time in "YYYYMMDD HH" format
my($etime) = shift(@ftppars); 

# Convert start and end time to seconds
$stime =~ s/\s//g;
$etime =~ s/\s//g;
my($syr2,$smn,$sday,$shr,$smin,$ssec);
$syr2 = substr($stime,2,2);
$smn = substr($stime,4,2);
$sday = substr($stime,6,2);
$shr = substr($stime,8,2);
$smin = 0;
$ssec = 0;
my($eyr2,$emn,$eday,$ehr,$emin,$esec);
$eyr2 = substr($etime,2,2);
$emn = substr($etime,4,2);
$eday = substr($etime,6,2);
$ehr = substr($etime,8,2);
$emin = 0;
$esec = 0;

$ssec =  &YMDHMS21970SEC($syr2,$smn,$sday,$shr,$smin,$ssec);
$esec =  &YMDHMS21970SEC($eyr2,$emn,$eday,$ehr,$emin,$esec);

rename("ftp.par1.txt","ftp.par1.txt.pcmd");

# Build api.par1.txt for ftp.par1.txt settings
shift(@ftppars);
shift(@ftppars);
shift(@ftppars);
shift(@ftppars);
$#dspars = -1;
$sprpln = "DEFAULT";
# Line 10 is first dataset line

#my(@procdatasets);
my(%procdatasets);
undef %procdatasets;
foreach $ds (@ftppars){
    $sprpln = "\U$ds";
    $sprpln =~ s/^\s//g;
    (@tmp) = split(" ",$sprpln);
#    print "PAR?? $tmp[0] --> $sprpln \n";
    if($#tmp > -1){    
	if($tmp[0] eq "Y"){    
	    $dsdefines = 0;
	    foreach $dskey (@datasetkeys){
		if(grep(/$dskey/,$sprpln)){  
#		    print "$dskey --> $datasetkeys{$dskey}\n";
		    $apidsyn{$datasetkeys{$dskey}}="Y";
#		    print "$dskey --> $datasetkeys{$dskey} -->   $apidsyn{$datasetkeys{$dskey}}\n";
		    $dsdefines = 1;
		    push(@datasetpath,$datasetpath{$dskey});
		    if(! defined $procdatasets{$datasetkeys{$dskey}}){
			$procdatasets{$datasetkeys{$dskey}} = $key2tpe{$datasetkeys{$dskey}};
			if(-e "$procdatasets{$datasetkeys{$dskey}}dump.txt.pcmd"){
			    unlink("$procdatasets{$datasetkeys{$dskey}}dump.txt.pcmd");
			}
		    }
		    last;
		}
	    }
# UNDEFINED CASE
	    if($dsdefines == 0){
		print "Uncoded dataset: $sprpln in ftp.par1.txt\n";
		print "Known datasets:\n@knowndskeys\n";
		if($interactive == 0){
		    print "Please enter return-key to terminate script:";
		    sysread(STDIN, $key, 100);
		    exit(0);
		}
	    }	    
	}
# Special path check
	elsif($tmp[0] eq "FTP"){
	    last;
	}
    }
}


#Read api.par1.txt
# read processing parms
open(IN,"api.par1.txt") || warn "Could not open api.par1.txt file in this directory, will not try to save file.\n";
my(@apipars);
$#apipars = -1;
(@apipars) =  <IN>;
close(IN);
if($#apipars > -1){
    rename("api.par1.txt","api.par1.txt.pcmd");
}



#####
#- Loop time by days
# dump hour
my($ssec_start00) = $ssec;
$ssec_start00 = $ssec_start00 - ($ssec_start00%(3600*24));
for($is=$ssec_start00; $is<=$esec; $is+=(3600*24)){
    $ies = $is + 3600*23;
    if($ies > $esec){$ies = $esec;}
    if($is < $ssec){
	$start = &TIMESTAMPDH($ssec);
    }
    else {
	$start = &TIMESTAMPDH($is);
    }
    $end = &TIMESTAMPDH($ies);
    $curday = &TIMESTAMPDAY($is);
    print "Processing day: $curday\n";
    $tmpftppars[3] = "$start    Start\n";
    $tmpftppars[4] = "$end    End\n";
    $apipartmhdlns[3] = "$start    Start";
    $apipartmhdlns[4] = "$end    End";


#Makeup new ftp.par1.txt script
    open (OUT,">ftp.par1.txt") || die "could not write to ftp.par1.txt";
    foreach $ln (@tmpftppars){
	print OUT "$ln";
    }
    close(OUT);



#Makeup new api.par1.txt script

    open (OUT,">api.par1.txt") || die "could not write to api.par1.txt";
# time and header
    foreach $ln (@apipartmhdlns){
	print OUT "$ln\n";
    }
# datasets
    for($i1=0;$i1<=$#apiparlns;$i1++){
	print OUT "$apidsyn{$apidsorder[$i1]}$apiparlns[$i1]\n";
    }
    close(OUT);
#
# FTP the files
    system "get_MADIS_Data_unix.pl $unm $pnm N";

# Run the API on the data files
    system "run_MADIS_API_unix.pl N";

# Check for data, save it to a temporary file
    foreach $dsnm (keys %procdatasets){
	if(-e "${dsnm}dump.txt"){
	    system "$cat ${dsnm}dump.txt >> ${dsnm}dump.txt.pcmd"; 
	}
    }

# Cleanup downloaded files
#    print "datasetpath --> @datasetpath\n";
    foreach $l (@datasetpath){
	$path = "$MADIS_DATA/$l";
#	print "path --> $path\n";
	if(-d "$path"){
	    opendir(DIRHANDLE,"$path");
	    @dirfiles=readdir (DIRHANDLE);
	    closedir (DIRHANDLE);
	    for($tmhr=0; $tmhr<=24; $tmhr++){
		$filehr = sprintf("%s_%0.2d",$curday,$tmhr);
		@datafiles= grep(/$filehr/,@dirfiles);
		foreach $df (@datafiles) {
		    unlink("$path/$df");
#		    print "Found data files -> TBR: $df\n";
		}
	    }
	}
    }
#    print "Done testing\n";
#    exit(0);

}
# restore any data found

# Check for found data, save it to normal output files
foreach $dsnm (keys %procdatasets){
    if(-e "${dsnm}dump.txt.pcmd"){
	rename("${dsnm}dump.txt.pcmd","${dsnm}dump.txt");
    }
}

# restore orginal [ftp/api].dump.txt
if($#apipars > -1){
    rename("api.par1.txt.pcmd","api.par1.txt");
}
rename("ftp.par1.txt.pcmd","ftp.par1.txt");


print "Script.  Please enter return-key to terminate";
print " script:";
sysread(STDIN, $key, 10);
exit(0);


############################################################
# function YMDHMS21970SEC(yr2,mn,day,hr,min,sec): Return time for date
sub YMDHMS21970SEC{
    my($yr2,$mn,$day,$hr,$min,$sec) = @_;
# seconds to this year
    my($seconds) = &YY21970SEC($yr2);
    my($julian) = &JDATE($yr2,$mn,$day);
# seconds to today
    if($julian > 0)
    {
        $seconds += (($julian-1)*24*3600);
    }
# seconds to today's time
    $seconds += ($hr*60*60) + ($min*60) + $sec;
    return ($seconds);
}

# Return seconds from 1970 to start of year
sub YY21970SEC{
    my($yr) = @_;
    my($yy) = $yr;
    if($yr < 1000){
	($yy) = 1900;
	$yy += $yr;
	if($yr < 70){
	    $yy += 100;
	}
    }
    my($i);
    my($leapyrs) = 0;
    foreach $i (1970...($yy-1)){
	$leapyrs += &LEAPDAY($i,12,1);
    }
    $yrdif = $yy - 1970;
    return($yrdif*365*86400 + $leapyrs*86400);
}

# Return 1 if we are after the leap day in a leap year.
sub LEAPDAY                  
{                            
    my($year,$month,$day) = @_;

    if ($year % 4) {
        return(0);
    }

if (!($year % 100)) {             # years that are multiples of 100
                                     # are not leap years
        if ($year % 400) {            # unless they are multiples of 400
            return(0);
        }
    }
    if ($month < 2) {
        return(0);
    } elsif (($month == 2) && ($day < 29)) {
        return(0);
    } else {
        return(1);
    }
}


# Purpose: Get day of the year for date
sub JDATE{
    my($yr,$mn,$day) = @_;
    my($i);
    my($jdays) = 0;
    my (@lyr) = (0,0,31,29,31,30,31,30,31,31,30,31,30,31);
    my (@ryr) = (0,0,31,28,31,30,31,30,31,31,30,31,30,31);
    my ($rem) = $yr;
    $rem %=4;
    if( $rem == 0 ){
	foreach $i (1...$mn){ $jdays += $lyr[$i];}
    }
    else {
	foreach $i (1...$mn){ $jdays += $ryr[$i];}
    }
    return($jdays + $day);
}


sub TIMESTAMPDH()
{
    my($tmsec) = @_;
    ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$rest) = gmtime($tmsec); 
    $year+= 1900;
    $yday++;
    $mon++;
    $mdyhms = sprintf("%0.4d%0.2d%0.2d %0.2d",$year,$mon,$mday,$hour);
    return($mdyhms);
}
sub TIMESTAMPDAY()
{
    my($tmsec) = @_;
    ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$rest) = gmtime($tmsec); 
    $year+= 1900;
    $yday++;
    $mon++;
    $mdyhms = sprintf("%0.4d%0.2d%0.2d",$year,$mon,$mday);
    return($mdyhms);
}
1;
