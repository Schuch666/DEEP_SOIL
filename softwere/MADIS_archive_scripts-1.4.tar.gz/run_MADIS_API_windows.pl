#!/usr/bin/perl -w
#
#
# This script dumps the data per the api.par1.txt parameter file.  It can be 
# used to drive one to all of the MADIS API dataset dump programs to 
# process a large batch of data already pulled from the MADIS archive.  One 
# output file per dataset is written.  The output file is named the same as
# the API dump file, i.e. METEOROLOGICAL SURFACE dump output is named 
# sfcdump.txt.  This script processes data one hour at a time.
#
#
# This only works for Windows.
#
# See README.windows for more documentation.
#
# Notes:
#
# 1. External commands:
#    - type
#    - dir
#
# 2. Editing the *dump.par1.txt datasets file:
#    These parameter files are the same style as the API "*dump.par" except 
#    without the date and time options.  See the API documentation for how to
#    edit the files.  The *dump.par1.txt files will be renamed to *dump.par and
#    the time information added when the program runs.
#      - Files
#                Name              Dataset
#        - acarsdump.par1.txt   -- acars 
#        - acarspdump.par1.txt  -- acarsp 
#        - hydrodump.par1.txt   -- hydro
#        - mapdump.par1.txt     -- map
#        - npndump.par1.txt     -- npn 
#        - raobdump.par1.txt    -- roab 
#        - rdmtrdump.par1.txt   -- rdmtr
#        - satraddump.par1.txt  -- satrad
#        - satsnddump.par1.txt  -- satsnd
#        - satwnddump.par1.txt  -- satwnd
#        - sfcdump.par1.txt     -- sfc
#        - snowdump.par1.txt    -- snow
#        - wisdomdump.par1.txt  -- WISDOM
#
# 3. A temporary file named *dump.txt.tmp" is used to hold the output information
#    for internal processing.
#
# 4. All parameter files are expected to be in the run time directory, the
#    same directory as run_MADIS_API.pl.
#
# Special variables defined:
#  %DS2ds
#     - key matches parameter file data set name
#     - value matches internal dataset name

$|=1;

use strict;
use POSIX qw(:termios_h);

my($cat,@datasets,$ds,@dspar,$exepath,@f,$f,$hour,$is,$key,$ln,$ls,$mday);
my($mdyhms,$min,$mon,$ofile,$ofiletmp,%ofiles,$p,@res,$rest,$sec,$tmpln);
my($year,$yrdif,@datasetkeys,@knowndskeys,$wday,$yday,$interactive);
my($sprpln,@tmp,$dsdefines,@dspars,@dspartmp,$i,$dskeys);


$cat = "type";
$ls = "dir";
# Default -- don't acknowledge before closing
$interactive = 1;

# turn interactive off.  ARGV[0] = N
# perl run_MADIS_API_windows.pl INTERACTIVE-NO[N]
if($#ARGV == 0 && $ARGV[0] eq "N"){    
    $interactive = 1;
}

# dataset code to dump code
#

my(%DS2ds) = (
	      "METEOROLOGICAL SURFACE"=>"sfc",
	      "HYDROLOGICAL SURFACE"=>"hydro",
	      "MULTI-AGENCY PROFILER"=>"map",
	      "SNOW"=>"snow",
	      "SATELLITE WIND"=>"satwnd",
	      "SATELLITE SOUNDING"=>"satsnd",
	      "RADIOMETER"=>"rdmtr",
	      "RADIOSONDE"=>"raob",
	      "SATELLITE RADIANCE"=>"satrad",
	      "AUTOMATED AIRCRAFT REPORTS"=>"acars",
	      "AUTOMATED AIRCRAFT PROFILES AT AIRPORTS"=>"acarsp",
	      "NOAA PROFILER NETWORK"=>"npn",
	      "WISDOM"=>"WISDOM",
);
# Conversion of key code to txt, par, and exe code
my(%key2tpe) = (
	      "sfc"=>"sfc",
	      "hydro"=>"hydro",
	      "map"=>"map",
	      "snow"=>"snow",
	      "satwnd"=>"satwnd",
	      "satsnd"=>"satsnd",
	      "rdmtr"=>"rdmtr",
	      "raob"=>"raob",
	      "satrad"=>"satrad",
	      "acars"=>"acars",
	      "acarsp"=>"acarsp",
	      "npn"=>"npn",
	      "WISDOM"=>"wisdom",
);

(@datasetkeys) = sort keys %DS2ds;
$#knowndskeys = -1;

foreach $dskeys (@datasetkeys){
    push(@knowndskeys,"\"$dskeys\"\n")
}


# read processing parms
open(IN,"api.par1.txt") || die "Could not open api.par1.txt file in this directory, please check that the file exists and is readable.\n";
my(@pars);
(@pars) =  <IN>;
close(IN);
chomp(@pars);

shift(@pars);
shift(@pars);
shift(@pars);
# Line 4 start time in "YYYYMMDD HH" format
my($stime) = shift(@pars); 
# Line 5 end time in "YYYYMMDD HH" format
my($etime) = shift(@pars); 

# Convert start and end time to seconds
$stime =~ s/\s//g;
$etime =~ s/\s//g;
my($syr2,$smn,$sday,$shr,$smin,$ssec);
$syr2 = substr($stime,2,2);
$smn = substr($stime,4,2);
$sday = substr($stime,6,2);
$shr = substr($stime,8,2);
$smin = 0;
$ssec = 0;
my($eyr2,$emn,$eday,$ehr,$emin,$esec);
$eyr2 = substr($etime,2,2);
$emn = substr($etime,4,2);
$eday = substr($etime,6,2);
$ehr = substr($etime,8,2);
$emin = 0;
$esec = 0;

$ssec =  &YMDHMS21970SEC($syr2,$smn,$sday,$shr,$smin,$ssec);
$esec =  &YMDHMS21970SEC($eyr2,$emn,$eday,$ehr,$emin,$esec);

# Unzip location, same as where the data is
my($MADIS_DATA) = $ENV{'MADIS_DATA'};
if($MADIS_DATA eq ""){
    print "MADIS_DATA is not defined, please define it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
elsif(! -d "$MADIS_DATA"){
    print "MADIS_DATA ($MADIS_DATA) directory does not exist, please create";
    print " it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}

my($MADIS_STATIC) = $ENV{'MADIS_STATIC'};
if($MADIS_STATIC eq ""){
    print "MADIS_STATIC is not defined, please define it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
elsif(! -d "$MADIS_STATIC"){
    print "MADIS_STATIC ($MADIS_STATIC) directory does not exist, please "; 
    print "create it then run again.\n"; 
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
my($MADIS_BIN) = $ENV{'MADIS_BIN'};
if($MADIS_BIN eq ""){
    print "MADIS_BIN is not defined, please define it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}
elsif(! -d "$MADIS_BIN"){
    print "MADIS_BIN ($MADIS_BIN) directory does not exist, please create ";
    print "it then run again.\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}

################################################################
# Read dataset(s) request
$#dspars = -1;
shift(@pars);
shift(@pars);
shift(@pars);
shift(@pars);
# Line 10 is first dataset line

foreach $ds (@pars){
    $sprpln = "\U$ds";
    $sprpln =~ s/^\s//g;
    (@tmp) = split(" ",$sprpln);
    if($tmp[0] eq "Y"){    
	$dsdefines = 0;
	foreach $dskeys (@datasetkeys){
	    if(grep(/$dskeys/,$sprpln)){
		push(@dspars,$dskeys);
		$dsdefines = 1;
		last;
	    }
	}
# UNDEFINED CASE
	if($dsdefines == 0){
	    print "Uncoded dataset: $sprpln\n";
	    print "Known datasets:\n@knowndskeys\n";
	    if($interactive == 0){
		print "Please enter return-key to terminate script:";
		sysread(STDIN, $key, 100);
		exit(0);
	    }
	}
    }
}

################################################################
# Dataset requested check
if($#dspars == -1){
    print "No dataset requested in api.par1.txt, please request a dataset";
    print " and run this again\n";
    if($interactive == 0){
	print "Please enter return-key to terminate script:";
	sysread(STDIN, $key, 100);
    }
    exit(0);
}


################################################################
# Dump request datasets
(@datasets) = sort @dspars;
$exepath = "$MADIS_BIN\\";

#my($dateloc);
foreach $ds (@datasets){

# dataset check
    if(exists $DS2ds{$ds}){
	my($dslcnm) = $DS2ds{$ds};
	$ofiletmp = "$key2tpe{$dslcnm}dump.txt.tmp";
	$ofile = "$key2tpe{$dslcnm}dump.txt";
	unlink("$ofile");
	unlink("$ofiletmp");
	
	
# original dump par file
	open(IN,"$key2tpe{$dslcnm}dump.par1.txt") || die "Could not open $key2tpe{$dslcnm}dump.par1.txt file in this directory, please check that the file exists and is readable.\n";
	(@dspartmp) =  <IN>;
	close(IN);
	$#dspar = -1;
	for($i=0; $i<=$#dspartmp; $i++){
# Fill in the time window for oen hour at a time.
	    if(grep(/Time Window/,$dspartmp[$i])){
		push(@dspar,$dspartmp[$i]);
		$i++;
		push(@dspar,$dspartmp[$i]);
		push(@dspar,"0             Number of minutes relative to nominal time at which to start window\n");
		if($DS2ds{$ds} eq "npn"){
		    push(@dspar,"0             Number of minutes relative to nominal time at which to end window\n");
		}
		else {
		    push(@dspar,"59            Number of minutes relative to nominal time at which to end window\n");
		}
	    }
# Fill in the time selection section, We will set the time field for each hour
# later on.
	    elsif(grep(/Time Selection/,$dspartmp[$i])){
		push(@dspar,$dspartmp[$i]);
		$i++;
		push(@dspar,$dspartmp[$i]);
		push(@dspar,"1             0 - Julian format (YYJJJHHMM)\n");
		push(@dspar,"              1 - Month/Day format (YYYYMMDD_HHMM)\n");
		push(@dspar,"0             0 - Use the nominal time line below\n");
		push(@dspar,"              1 - Use the current time as the nominal time\n");
		push(@dspar,"YYYYMMDD_HHMM Nominal time (in selected format)\n");
	    }
	    else {
		push(@dspar,$dspartmp[$i]);
	    }
	}


# dump hour
	for($is=$ssec; $is<=$esec; $is+=3600){
	    $f = &TIMESTAMP($is);
	    print "Dumping $ds for time ${f}.\n";
# exe's version of dump par file
	    open (OUT,">$key2tpe{$dslcnm}dump.par") || die "could not open $key2tpe{$dslcnm}dump.par";
	    foreach $ln (@dspar){
		$tmpln = $ln;
		$tmpln =~ s/YYYYMMDD_HHMM/$f/;


		print OUT "$tmpln";
	    }
	    close(OUT);
# run the dump program
	    unlink("$key2tpe{$dslcnm}dump.txt");
	    @res = `${exepath}$key2tpe{$dslcnm}dump.exe`;
	    system "$cat $ofile >> $ofiletmp"; 
	    unlink("$ofile");
	}
	rename($ofiletmp,$ofile);
	system "$ls $ofile";
    }
    else {
	print "Uncoded dataset: $ds\n";
	if($interactive == 0){
	    print "Please enter return-key to terminate script:";
	    sysread(STDIN, $key, 100);
	    exit(0);
	}
    }
}

print "Script completed.";
if($interactive == 0){
    print "Please enter return-key to terminate script:";
    sysread(STDIN, $key, 100);
}
exit(0);


############################################################
# function YMDHMS21970SEC(yr2,mn,day,hr,min,sec): Return time for date
sub YMDHMS21970SEC{
    my($yr2,$mn,$day,$hr,$min,$sec) = @_;
# seconds to this year
    my($seconds) = &YY21970SEC($yr2);
    my($julian) = &JDATE($yr2,$mn,$day);
# seconds to today
    if($julian > 0)
    {
        $seconds += (($julian-1)*24*3600);
    }
# seconds to today's time
    $seconds += ($hr*60*60) + ($min*60) + $sec;
    return ($seconds);
}

# Return seconds from 1970 to start of year
sub YY21970SEC{
    my($yr) = @_;
    my($yy) = $yr;
    if($yr < 1000){
	($yy) = 1900;
	$yy += $yr;
	if($yr < 70){
	    $yy += 100;
	}
    }
    my($i);
    my($leapyrs) = 0;
    foreach $i (1970...($yy-1)){
	$leapyrs += &LEAPDAY($i,12,1);
    }
    $yrdif = $yy - 1970;
    return($yrdif*365*86400 + $leapyrs*86400);
}

# Return 1 if we are after the leap day in a leap year.
sub LEAPDAY                  
{                            
    my($year,$month,$day) = @_;

    if ($year % 4) {
        return(0);
    }

if (!($year % 100)) {             # years that are multiples of 100
                                     # are not leap years
        if ($year % 400) {            # unless they are multiples of 400
            return(0);
        }
    }
    if ($month < 2) {
        return(0);
    } elsif (($month == 2) && ($day < 29)) {
        return(0);
    } else {
        return(1);
    }
}


# Purpose: Get day of the year for date
sub JDATE{
    my($yr,$mn,$day) = @_;
    my($i);
    my($jdays) = 0;
    my (@lyr) = (0,0,31,29,31,30,31,30,31,31,30,31,30,31);
    my (@ryr) = (0,0,31,28,31,30,31,30,31,31,30,31,30,31);
    my ($rem) = $yr;
    $rem %=4;
    if( $rem == 0 ){
	foreach $i (1...$mn){ $jdays += $lyr[$i];}
    }
    else {
	foreach $i (1...$mn){ $jdays += $ryr[$i];}
    }
    return($jdays + $day);
}


sub TIMESTAMP()
{
    my($tmsec) = @_;
    ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$rest) = gmtime($tmsec); 
    $year+= 1900;
    $yday++;
    $mon++;
    $mdyhms = sprintf("%0.4d%0.2d%0.2d_%0.2d%0.2d",$year,$mon,$mday,$hour,$min);
    return($mdyhms);
}
1;
